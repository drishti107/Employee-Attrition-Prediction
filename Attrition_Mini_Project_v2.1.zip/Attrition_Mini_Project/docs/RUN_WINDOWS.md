# Run on Windows

1. Download and extract the entire project ZIP. Open Anaconda Prompt in the extracted `Attrition_Mini_Project` folder containing `app.py`.
2. Create and activate an environment:

```bat
conda create -n attrition-project python=3.12 -y
conda activate attrition-project
python -m pip install -r requirements.txt
python verify.py
python -m streamlit run app.py
```

Open the local URL printed in the terminal. Stop the app with Ctrl+C. Reopen it later by activating the environment and running the Streamlit command again. No GPU or paid API is required. A network connection is needed to install packages; the supplied model and dataset run locally afterward.

If the model fails to load, confirm Python and dependency versions (`python --version`, `python -m pip show scikit-learn`) and that the complete ZIP was extracted. Run commands from the folder containing `app.py`, not inside the ZIP viewer. Do not install a different scikit-learn version and assume serialized models are compatible.

For Jupyter:

```bat
python -m jupyterlab
```

Open `notebooks/Attrition_Project_Walkthrough.ipynb`. It analyzes the included saved results; full cross-validation is deliberately a separate script.

To reproduce the experiment in a new sibling folder:

```bat
python -m pip install -r requirements-report.txt
python reproduce.py --destination ..\Attrition_Reproduced --jobs 4
```

The full run includes 350 outer model fits with tuning and 7,500 bootstrap refits. Use fewer jobs if memory is limited. The original results remain untouched. Install `requirements-report.txt` if rebuilding the Word report. The delivered tests were executed in Linux; these Windows setup commands were not claimed as an executed Windows test.

## Windows verification (v2.1)

`verify.py` was run on Windows 11 in the pinned requirements environment. Results and details are in `docs/WINDOWS_VERIFICATION.md`.
