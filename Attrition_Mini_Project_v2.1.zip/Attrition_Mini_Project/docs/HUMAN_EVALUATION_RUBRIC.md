# Human clarity evaluation — protocol, not a completed study

**Status: not performed.** No participant ratings, sample size, or positive human-evaluation result is claimed. The numerical K80, stability and ranking diagnostics do not establish human understanding.

Recruit 5–10 consenting classmates for a voluntary, anonymous coursework exercise. Use fictional profiles only and participant codes P01–P10. Explain that this is a model explanation exercise and that there are no real employment consequences. Do not collect names, demographic attributes or employer information.

## Materials and design

Use the same 5 preselected fictional profiles for everyone. Select these by fixed source row indices 0, 100, 200, 300 and 400, before collecting ratings. Present original-feature and seven-feature logistic explanations as A/B with the same typography, top-five contribution count, units, baseline explanation and caution about associations. Randomly assign half the participants original first and half engineered first. Record the assigned ordering. Hide model names and engineered labels during rating, but retain feature definitions. Do not show the true label or claim that one explanation is better. The app's illustrative high-risk employee 478 is not the evaluation sample.

Each participant sees 10 explanations. After each, collect:

| Question | 1 | 3 | 5 |
|---|---|---|---|
| Clarity: I understand what the main factors mean. | Very unclear | Partly clear | Very clear |
| Usefulness: This helps me describe the model's prediction. | Not useful | Moderately useful | Very useful |
| Confidence: I can explain the direction of the main contributions. | Not confident | Somewhat confident | Very confident |

Values 2 and 4 are intermediate. Ask the participant to identify the largest increasing factor and one decreasing factor (or correctly state none). Separately ask: “Does this explanation prove that changing a factor will reduce attrition?” Correct answer: No. Allow an optional free-text note about a confusing feature or unit. Do not coach between A and B.

## Analysis plan

Decode A/B only after ratings are complete. Compute each participant's average clarity and usefulness separately for the two representations, then paired participant-level differences. Report raw scores, medians, interquartile ranges, and every participant-level difference. With only 5–10 people, emphasize descriptive results and avoid strong population claims. If an interval is reported, bootstrap participants as clusters, not 50 repeated ratings as independent observations. Report the exact sample size, counterbalancing, missing ratings and excluded records. Summarize comprehension accuracy separately from preference ratings.

A human benefit requires improved clarity/usefulness and acceptable comprehension, alongside the prediction results. Do not replace empty cells with fabricated ratings. The CSV template deliberately contains only its header.

## Status update (v2.1)

- Materials built by `scripts/human_study_kit.py`: `human_study/cards/P01.md` to `P10.md`, `participant_assignments.csv`, and a researcher-only `KEY_do_not_distribute.csv`. Thresholds are not shown on cards, since they differ between models and would reveal which explanation is which.
- Assignment alternates original-first and engineered-first across participants (5 and 5). The rubric asked for random assignment; for a 10-person study, alternation is a deliberate balance choice. Change it if you prefer random.
- Analysis: `scripts/analyze_human_responses.py` reads `human_study/responses.csv` and writes `results/human_study/analysis.json`. Without responses it writes status "not performed".
- **Still not performed.** No ratings exist in this project.
