# Results and conclusion

The study does not demonstrate simultaneous improvement in prediction and interpretability for the seven-feature logistic model; the measured trade-offs must be reported separately. The seven-feature logistic model changes mean average precision from 0.6172 to 0.6282 (paired difference +0.0111; corrected 95% interval [-0.0131, +0.0353]). Top-three stability changes by -0.0338, while K80 changes by +1.43 attributes (lower K80 is better). No human clarity study has been performed.

The corrected interval includes zero, so the apparent performance difference is uncertain. Holm-adjusted AP p-value: 1.0000.

The original eight-feature logistic arm has mean AP 0.6413, a change of +0.0241 versus original predictors (corrected 95% interval [-0.0014, +0.0496]; 23/25 fold wins). Forest AP changes are +0.0002 with eight features and +0.0067 with seven; their corrected intervals include zero. Both engineered decision-tree arms have lower mean AP than the original arm.

For the eight-feature logistic arm, stability changes by +0.0341 and K80 by +1.02. Interpretability dimensions must therefore be assessed separately.

The eight-feature arms reproduce the original feature specification. The seven-feature arms remove LogMonthlyIncome and are eligible for deployment alongside original-feature models. Model selection was fixed by mean nested-CV AP, lower Brier then key. Ablations and age sensitivity are diagnostic only.

## Predictive comparisons

| model                      | family   | feature_mode      |   average_precision_mean |   average_precision_std |   roc_auc_mean |   roc_auc_std |   brier_mean |   brier_std |   ece_mean |    ece_std |   accuracy_mean |   accuracy_std |   precision_mean |   precision_std |   recall_mean |   recall_std |   f1_mean |    f1_std |
|:---------------------------|:---------|:------------------|-------------------------:|------------------------:|---------------:|--------------:|-------------:|------------:|-----------:|-----------:|----------------:|---------------:|-----------------:|----------------:|--------------:|-------------:|----------:|----------:|
| forest_all                 | forest   | all               |                 0.539654 |               0.0664403 |       0.801101 |     0.0385135 |    0.104943  |  0.00725605 |  0.0449893 | 0.0120518  |        0.83034  |      0.0281739 |         0.486276 |       0.0710237 |      0.569539 |    0.0663278 |  0.521148 | 0.0529729 |
| forest_no_log              | forest   | no_log            |                 0.546099 |               0.0643529 |       0.800455 |     0.0356371 |    0.104157  |  0.0070389  |  0.0403908 | 0.00939079 |        0.826395 |      0.031073  |         0.477517 |       0.0686148 |      0.570408 |    0.0919336 |  0.514298 | 0.0610847 |
| forest_raw                 | forest   | raw               |                 0.539446 |               0.0682009 |       0.797328 |     0.037857  |    0.105062  |  0.00778303 |  0.0432059 | 0.0121549  |        0.824626 |      0.0275643 |         0.472138 |       0.0731262 |      0.567004 |    0.0772815 |  0.511124 | 0.0564322 |
| logistic_all               | logistic | all               |                 0.641302 |               0.0462981 |       0.831771 |     0.0301824 |    0.0935902 |  0.00650666 |  0.0456845 | 0.0113414  |        0.85619  |      0.0217687 |         0.564894 |       0.0796523 |      0.570337 |    0.0838649 |  0.560339 | 0.0543591 |
| logistic_no_log            | logistic | no_log            |                 0.628244 |               0.0500518 |       0.828716 |     0.031081  |    0.0948361 |  0.00652229 |  0.0408002 | 0.0105025  |        0.857959 |      0.0206496 |         0.572388 |       0.0762929 |      0.559433 |    0.0960775 |  0.557387 | 0.0558521 |
| logistic_no_log_age        | logistic | no_log_age        |                 0.6311   |               0.0539349 |       0.829012 |     0.0302622 |    0.0941478 |  0.00666238 |  0.0443985 | 0.0107992  |        0.856871 |      0.0248579 |         0.567862 |       0.0860237 |      0.592411 |    0.0790993 |  0.572271 | 0.0494909 |
| logistic_raw               | logistic | raw               |                 0.617185 |               0.0536915 |       0.825423 |     0.030452  |    0.0961597 |  0.00650715 |  0.044647  | 0.010798   |        0.856054 |      0.0205897 |         0.56504  |       0.0811095 |      0.556259 |    0.0679213 |  0.554948 | 0.0454868 |
| logistic_without_career    | logistic | without_career    |                 0.621386 |               0.0556362 |       0.824312 |     0.031996  |    0.0961245 |  0.0065784  |  0.0482063 | 0.0102074  |        0.858367 |      0.0224953 |         0.576637 |       0.0852892 |      0.550319 |    0.073435  |  0.556379 | 0.0485453 |
| logistic_without_reward    | logistic | without_reward    |                 0.622523 |               0.0518229 |       0.829177 |     0.0298482 |    0.0949382 |  0.00670824 |  0.0418496 | 0.0108051  |        0.85415  |      0.0242174 |         0.560316 |       0.0824736 |      0.588333 |    0.0832978 |  0.565175 | 0.0486914 |
| logistic_without_sentiment | logistic | without_sentiment |                 0.627954 |               0.0506178 |       0.828597 |     0.0311899 |    0.0948483 |  0.00653857 |  0.0410376 | 0.0108426  |        0.853741 |      0.0226899 |         0.558467 |       0.0806612 |      0.573723 |    0.0957841 |  0.55698  | 0.0549064 |
| logistic_without_workload  | logistic | without_workload  |                 0.632939 |               0.0453091 |       0.830621 |     0.0295708 |    0.0944971 |  0.00603749 |  0.0438068 | 0.00982199 |        0.856599 |      0.0238839 |         0.56643  |       0.0777938 |      0.57883  |    0.0777034 |  0.565767 | 0.0479475 |
| tree_all                   | tree     | all               |                 0.387544 |               0.0574989 |       0.722042 |     0.0404418 |    0.126572  |  0.00269043 |  0.0686979 | 0.0235931  |        0.786395 |      0.0441304 |         0.394027 |       0.0788267 |      0.503794 |    0.093366  |  0.433523 | 0.0546247 |
| tree_no_log                | tree     | no_log            |                 0.385515 |               0.0599866 |       0.72534  |     0.0449554 |    0.126383  |  0.00361235 |  0.0675015 | 0.0220988  |        0.773469 |      0.0467507 |         0.374309 |       0.079058  |      0.512092 |    0.0888211 |  0.424    | 0.0511264 |
| tree_raw                   | tree     | raw               |                 0.400728 |               0.0654043 |       0.725726 |     0.0344531 |    0.125761  |  0.0050036  |  0.0657412 | 0.0271209  |        0.786122 |      0.0434181 |         0.39538  |       0.0738312 |      0.519699 |    0.0988625 |  0.440367 | 0.0529585 |

## Paired comparisons

| comparison   | reference       | candidate                  | metric            |   difference |       ci_low |     ci_high |   corrected_se |   p_two_sided |   wins |   ties |   folds |   p_holm_AP |
|:-------------|:----------------|:---------------------------|:------------------|-------------:|-------------:|------------:|---------------:|--------------:|-------:|-------:|--------:|------------:|
| all          | logistic_raw    | logistic_all               | average_precision |  0.0241173   | -0.00139386  | 0.0496284   |    0.0123607   |     0.062809  |     23 |      0 |      25 |    0.188427 |
| all          | logistic_raw    | logistic_all               | roc_auc           |  0.00634791  | -0.00591713  | 0.0186129   |    0.00594265  |     0.29606   |     20 |      0 |      25 |  nan        |
| all          | logistic_raw    | logistic_all               | brier             | -0.00256952  | -0.00531337  | 0.000174331 |    0.00132945  |     0.0651485 |     22 |      0 |      25 |  nan        |
| all          | tree_raw        | tree_all                   | average_precision | -0.0131845   | -0.0602209   | 0.0338519   |    0.0227901   |     0.568303  |      8 |      0 |      25 |    1        |
| all          | tree_raw        | tree_all                   | roc_auc           | -0.00368464  | -0.038126    | 0.0307567   |    0.0166875   |     0.827114  |     10 |      0 |      25 |  nan        |
| all          | tree_raw        | tree_all                   | brier             |  0.000810629 | -0.00391456  | 0.00553581  |    0.00228945  |     0.726377  |     10 |      0 |      25 |  nan        |
| all          | forest_raw      | forest_all                 | average_precision |  0.000207869 | -0.0265733   | 0.026989    |    0.012976    |     0.987351  |     11 |      0 |      25 |    1        |
| all          | forest_raw      | forest_all                 | roc_auc           |  0.00377336  | -0.012178    | 0.0197247   |    0.00772875  |     0.629822  |     15 |      0 |      25 |  nan        |
| all          | forest_raw      | forest_all                 | brier             | -0.000118755 | -0.00255295  | 0.00231544  |    0.00117941  |     0.920633  |     13 |      0 |      25 |  nan        |
| no_log       | logistic_raw    | logistic_no_log            | average_precision |  0.0110596   | -0.0131486   | 0.0352679   |    0.0117294   |     0.355129  |     15 |      0 |      25 |    1        |
| no_log       | logistic_raw    | logistic_no_log            | roc_auc           |  0.00329297  | -0.00759299  | 0.0141789   |    0.00527446  |     0.538305  |     15 |      0 |      25 |  nan        |
| no_log       | logistic_raw    | logistic_no_log            | brier             | -0.00132353  | -0.00393967  | 0.00129261  |    0.00126757  |     0.306821  |     18 |      0 |      25 |  nan        |
| no_log       | tree_raw        | tree_no_log                | average_precision | -0.0152131   | -0.0635602   | 0.033134    |    0.0234251   |     0.522224  |      8 |      0 |      25 |    1        |
| no_log       | tree_raw        | tree_no_log                | roc_auc           | -0.000386554 | -0.0389758   | 0.0382027   |    0.0186973   |     0.983676  |     12 |      0 |      25 |  nan        |
| no_log       | tree_raw        | tree_no_log                | brier             |  0.000621531 | -0.00491606  | 0.00615913  |    0.00268308  |     0.818774  |     11 |      0 |      25 |  nan        |
| no_log       | forest_raw      | forest_no_log              | average_precision |  0.00665247  | -0.0261879   | 0.0394929   |    0.0159118   |     0.679603  |     14 |      0 |      25 |    1        |
| no_log       | forest_raw      | forest_no_log              | roc_auc           |  0.00312742  | -0.017209    | 0.0234638   |    0.00985339  |     0.753688  |     14 |      0 |      25 |  nan        |
| no_log       | forest_raw      | forest_no_log              | brier             | -0.000905386 | -0.00368104  | 0.00187026  |    0.00134486  |     0.507238  |     16 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_workload  | average_precision |  0.00469432  | -0.0118345   | 0.0212231   |    0.00800854  |     0.563238  |     14 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_workload  | roc_auc           |  0.00190517  | -0.00433229  | 0.00814263  |    0.00302217  |     0.534392  |     15 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_workload  | brier             | -0.000339098 | -0.00186025  | 0.00118206  |    0.00073703  |     0.649595  |     11 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_career    | average_precision | -0.00685853  | -0.0286144   | 0.0148973   |    0.0105411   |     0.521457  |      9 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_career    | roc_auc           | -0.00440362  | -0.0121495   | 0.00334223  |    0.00375302  |     0.252168  |      6 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_career    | brier             |  0.00128839  | -0.00056066  | 0.00313743  |    0.0008959   |     0.163321  |      7 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_reward    | average_precision | -0.00572134  | -0.0204405   | 0.00899782  |    0.00713172  |     0.430288  |     10 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_reward    | roc_auc           |  0.00046115  | -0.0081222   | 0.0090445   |    0.00415881  |     0.91263   |     12 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_reward    | brier             |  0.000102091 | -0.00166884  | 0.00187302  |    0.000858052 |     0.906281  |     15 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_sentiment | average_precision | -0.000290758 | -0.00243201  | 0.00185049  |    0.00103748  |     0.781684  |     12 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_sentiment | roc_auc           | -0.000119028 | -0.000674879 | 0.000436823 |    0.000269321 |     0.662477  |     11 |      0 |      25 |  nan        |
| ablation     | logistic_no_log | logistic_without_sentiment | brier             |  1.21005e-05 | -5.0082e-05  | 7.42829e-05 |    3.01286e-05 |     0.691512  |     11 |      0 |      25 |  nan        |
| age          | logistic_no_log | logistic_no_log_age        | average_precision |  0.00285612  | -0.0115071   | 0.0172194   |    0.00695927  |     0.68515   |     17 |      0 |      25 |  nan        |
| age          | logistic_no_log | logistic_no_log_age        | roc_auc           |  0.000296148 | -0.00509296  | 0.00568525  |    0.00261113  |     0.910643  |     16 |      0 |      25 |  nan        |
| age          | logistic_no_log | logistic_no_log_age        | brier             | -0.000688357 | -0.00174545  | 0.000368734 |    0.000512182 |     0.191526  |     20 |      0 |      25 |  nan        |

## Interpretation differences

| reference    | candidate       | metric       |   difference |     ci_low |    ci_high |
|:-------------|:----------------|:-------------|-------------:|-----------:|-----------:|
| logistic_raw | logistic_all    | mean_k80     |    1.01687   |  0.886667  |  1.14245   |
| logistic_raw | logistic_all    | top3_jaccard |    0.0341216 |  0.0255494 |  0.0417747 |
| logistic_raw | logistic_all    | spearman     |    0.046833  |  0.028928  |  0.0647381 |
| logistic_raw | logistic_no_log | mean_k80     |    1.42653   |  1.25143   |  1.60163   |
| logistic_raw | logistic_no_log | top3_jaccard |   -0.0337505 | -0.0400835 | -0.0274095 |
| logistic_raw | logistic_no_log | spearman     |    0.0109288 | -0.0115235 |  0.0360057 |
| forest_raw   | forest_all      | mean_k80     |    4.49224   |  3.92939   |  5.0551    |
| forest_raw   | forest_all      | top3_jaccard |   -0.108253  | -0.116659  | -0.0956373 |
| forest_raw   | forest_all      | spearman     |   -0.0710473 | -0.119437  | -0.0145951 |
| forest_raw   | forest_no_log   | mean_k80     |    3.61034   |  3.20531   |  3.96735   |
| forest_raw   | forest_no_log   | top3_jaccard |   -0.086     | -0.090978  | -0.0810449 |
| forest_raw   | forest_no_log   | spearman     |   -0.0800598 | -0.122074  | -0.0279634 |

Predictive intervals use an approximate corrected resampled t method; AP p-values are Holm-adjusted over three families separately for each specification. Interpretability intervals bootstrap five repeat means and describe conditional split variation, not population uncertainty.

Selecting the final family from outer-CV results adds selection optimism; the supplied full-data deployment model has no new independent test. The old 70/20/10 study is a historical archive only.

## Addendum (v2.1): gap closure results

These results were added after the first review. Each section states what was run. Nothing here changes the original nested-CV tables.

### Locked holdout (independent of selection)

A fixed stratified split (seed 20260101) set aside 294 employees before any comparison. Selection used the other 1,176 rows with the same nested-CV rules. The same winner was chosen: `logistic_no_log`. It was refitted on the 1,176 rows and scored once on the holdout.

| Model | Holdout AP | Holdout ROC-AUC | Holdout Brier | Holdout F1 |
|---|---|---|---|---|
| logistic_no_log (selected) | 0.6300 | 0.8630 | 0.0927 | 0.5918 |
| logistic_raw | 0.6106 | 0.8568 | 0.0930 | 0.5814 |
| forest_raw | 0.4994 | 0.8126 | 0.1075 | 0.4954 |
| forest_no_log | 0.4746 | 0.7692 | 0.1114 | 0.5000 |
| tree_raw | 0.3323 | 0.6900 | 0.1255 | 0.3922 |
| tree_no_log | 0.3304 | 0.7222 | 0.1266 | 0.4444 |

Holdout AP difference, selected minus logistic_raw: **+0.0194**, bootstrap 95% interval **[-0.0667, +0.0797]** over 294 employees. The interval includes zero. The holdout confirms the earlier direction but does not establish a performance gain.

The 1,176-row development CV gave logistic_no_log AP 0.6044 and logistic_raw AP 0.6026 (25 folds). The holdout is an internal split of the same fictional data. It is not an external or temporal test.

### Subgroup audit (Gender, MaritalStatus, age band)

Saved held-out predictions for the selected model (logistic_no_log, 1,470 employees, 5 repeats each). Gaps are largest minus smallest group. Intervals resample employees.

| Attribute | Flagged-rate gap [95%] | True-positive gap [95%] | False-positive gap [95%] |
|---|---|---|---|
| Gender | 0.018 [0.001, 0.056] | 0.068 [0.003, 0.187] | 0.021 [0.001, 0.049] |
| MaritalStatus | 0.128 [0.087, 0.178] | 0.231 [0.125, 0.367] | 0.042 [0.012, 0.078] |
| AgeBand | 0.163 [0.115, 0.213] | 0.275 [0.137, 0.408] | 0.049 [0.015, 0.095] |

Observed attrition rate by group: Single 25.5%, Married 12.5%, Divorced 10.1%; under 30 27.9%, 30 to 39 14.3%, 40 and over 10.9%.

Interpretation:
- Flagged-rate gaps partly follow base-rate differences. They are not, by themselves, evidence of unfair treatment.
- True-positive gaps are the more concerning result. The model finds a smaller share of actual leavers among married and 40-plus employees (TPR 0.42 and 0.40) than among single and under-30 employees (0.65 and 0.68). Interval lower bounds are above zero for these gaps.
- The excluded attributes are not inputs, but other inputs still carry this signal.
- **Not mitigated.** The gaps are measured and reported. No reweighting or fairness-constrained model was tried.

### Human clarity study

Status: **not performed**. The packet is ready: 10 participant cards, a counterbalanced A/B assignment, a researcher-only key, and an analysis script. No ratings have been collected or created. Until people rate the explanations, interpretability is measured only by K80 and stability proxies.

### Temporal validation

Status: **not performed**. The dataset has no observation or departure dates. `scripts/temporal_validation.py` runs once a dated extract with a stated horizon is provided. It was checked only for code correctness, on a scratch copy with random dates. Those numbers are not evidence and were not saved to results.
