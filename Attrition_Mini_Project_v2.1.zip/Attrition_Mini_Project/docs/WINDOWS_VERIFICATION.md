# Windows verification record (v2.1)

This records what was actually run on Windows. It does not claim more than that.

## Environment

- OS: Windows 11 Home (10.0.26200)
- Python: 3.13.7 (`C:\Python313`). The docs recommend 3.12; 3.12 was not installed on this machine. The pinned packages support 3.13, so this is a deviation from the recommendation.
- Install: `python -m pip install -r requirements.txt` in a fresh venv, plus `python-docx==1.2.0` for the report build.
- Installed versions (from pins): numpy 2.3.5, pandas 2.2.3, scikit-learn 1.8.0, shap 0.50.0, streamlit 1.65.0, joblib 1.5.3.

## Commands run and results

| Command | Result |
|---|---|
| `python verify.py` | **PASS**. All 8 checks passed, including the SHA-256 manifest, matched folds, metric recomputation, paired intervals, interpretability coverage, worked example and core tests. The manifest check failed on the first run because README and docs were edited; it passed after `scripts/checksums.py` was rerun. |
| `python tests/test_app.py` | **PASS**. UI loads tables, predicts, compares explanations, rejects invalid profiles, recovers from stale results. |
| `python tests/test_human_analysis.py` | **PASS**. Synthetic in-memory frames only. |
| `python scripts/locked_holdout.py --jobs 6` | Completed. See `results/holdout/`. |
| `python scripts/fairness_audit.py` | Completed. See `results/fairness/`. |
| `python scripts/human_study_kit.py` | Completed. 10 participant cards written. No ratings. |
| `python scripts/analyze_human_responses.py` | Wrote status "not performed" (no `responses.csv`). |
| `python scripts/build_report.py` | Completed. Report regenerated with a gap-closure section. |
| `python scripts/temporal_validation.py` | Code smoke test only, on a scratch file with random dates, output outside the project. Not evidence. |

## Not run

- `python -m streamlit run app.py` was not started interactively. The UI test covers the same code paths.
- Full reproduction (`reproduce.py`, 350 outer fits plus 7,500 bootstrap refits) was not repeated. The saved results were used and checked by `verify.py`.
- `verify.py --with-cache` needs the `.cache/` checkpoints, which are not in the distributable. Not run.
- Jupyter notebook re-execution was not run.

## Issues found on Windows

- A first pip install failed with file-lock errors (`WinError 32`). Two concurrent installs into the same venv caused it. Installing once, cleanly, fixed it. This is a setup hazard, not a project bug.
- Human study card formatting failed once on a non-numeric feature value (`value` was text). Fixed in `scripts/human_study_kit.py`.
