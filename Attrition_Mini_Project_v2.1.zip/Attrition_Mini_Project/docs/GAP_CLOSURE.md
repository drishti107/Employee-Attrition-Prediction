# Gap closure status (v2.1)

Each gap from the coverage review is listed with what was done and what remains. Items marked **open** need data or people that this project does not have. They were not faked.

| # | Gap | Status | What was done | Evidence / file | What is still open |
|---|---|---|---|---|---|
| 1 | No human interpretability evidence | **Open** (materials ready) | Built the blinded packet: 10 participant cards, counterbalanced A/B, researcher-only key, analysis script. Thresholds removed from cards so the two models cannot be told apart by that. | `human_study/`, `scripts/human_study_kit.py`, `scripts/analyze_human_responses.py`, `results/human_study/status.json` | Run the study with 5-10 people and fill `human_study/responses.csv`. |
| 2 | "Turnover probability" is a label probability; no dates | **Open** (tool ready) | Wrote a forward-in-time validation script that needs a dated extract plus a stated horizon. Smoke-tested on a scratch file only. | `scripts/temporal_validation.py` | Needs a dated attrition dataset. The IBM file has no dates. |
| 3 | No independent test | **Partly closed** | Locked holdout: 294 employees split off with a fixed seed. Selection on the other 1,176 rows only. Winner scored once. | `results/holdout/`, `scripts/locked_holdout.py` | Still the same fictional dataset, so it is internal, not external. Holdout AP difference vs original logistic is +0.019 with interval [-0.067, +0.080]. |
| 4 | Fairness not measured | **Partly closed; disparities found** | Subgroup audit by Gender, MaritalStatus and age band, with employee-level bootstrap. Single and under-30 employees have higher true-positive rates. Married and 40-plus employees have lower true-positive rates; these gaps are resolvable (intervals exclude zero). | `results/fairness/`, `scripts/fairness_audit.py` | Disparities **not mitigated**. No reweighting or constrained model tried. Proxy effects remain possible. |
| 5 | Windows execution not verified | **Closed** | Ran pinned environment and `verify.py`, `test_app.py`, and new tests on Windows 11 with Python 3.13 (docs recommend 3.12). | `docs/WINDOWS_VERIFICATION.md` | Python 3.12 not tested on Windows. |
| 6 | README encoding (mojibake) | **Not a defect** | Checked bytes. README is valid UTF-8. The garbled characters appeared only in a Windows console view. | `README.md` bytes | None. |

## Summary

- Closed: 5 (Windows verification), 6 (not a defect).
- Partly closed: 3 (internal holdout), 4 (audit done, disparities found, not fixed).
- Open: 1 (human study), 2 (dated data).

The objective answer is unchanged: the seven-feature logistic model does not show a significant simultaneous gain in performance and interpretability. The new holdout result is consistent with that.
