# Employee Attrition Prediction with Domain Guided Features

Research question: Can domain-guided feature engineering simultaneously improve predictive performance and interpretability?

### Abstract

This system predicts the fictional IBM HR dataset’s attrition label and explains the major factors associated with an individual prediction. The upgraded experiment uses all 1,470 employees in five repeats of five-fold nested stratified cross-validation. Logistic regression, decision trees and random forests are compared under original, eight-feature and seven-feature representations. Four block ablations, an age sensitivity analysis, sigmoid probability calibration and training-CV threshold selection are included. Explanation diagnostics cover every held-out employee, with 50 bootstrap refits per outer fold, and include random forests.

The study does not demonstrate simultaneous improvement in prediction and interpretability for the seven-feature logistic model; the measured trade-offs must be reported separately. The seven-feature logistic model changes mean average precision from 0.6172 to 0.6282 (paired difference +0.0111; corrected 95% interval [-0.0131, +0.0353]). Top-three stability changes by -0.0338, while K80 changes by +1.43 attributes (lower K80 is better). No human clarity study has been performed.

### Objective to evidence mapping

| Professor’s objective | Implemented evidence |
| --- | --- |
| Estimate individual turnover probability | Calibrated probability plus a training-CV thresholded class |
| Identify principal associated factors | Signed group contributions and named domain attributes |
| Investigate feature engineering | Matched nested folds, original +8 and original +7 variants, ablations |
| Evaluate interpretability with performance | K80, top-three stability, ranking agreement and uncertainty |

The final deployment model is logistic_no_log, refitted on all development records. Its threshold is 0.290. Reported outer-CV scores evaluate the training procedure; they are not an independent test of this final refit.

Educational scope: fictional, cross-sectional data with no defined forecast horizon. No human clarity study has been performed.

## Data and experimental design

The source dataset contains 1,470 records and 35 columns, including Attrition. There are 237 Yes labels (16.12%) and 1,233 No labels. The source describes the data as fictional [1]. The supplied CSV is fingerprinted; missing cells and employee-ID duplicates are checked before training. No dated departure or observation window is provided.

### Predictor policy

The main models use 27 original predictors. EmployeeNumber is an identifier; EmployeeCount, Over18 and StandardHours are constant. These are removed. Age, Gender and MaritalStatus are excluded from the principal study. Age is added only in a separate sensitivity analysis. Excluding demographics does not establish fairness because other inputs may proxy them.

### Matched repeated nested cross-validation

| Stage | Design | Role |
| --- | --- | --- |
| Outer evaluation | 5 repeats × 5 stratified folds | 25 matched test folds; each has 294 test and 1,176 training rows |
| Inner tuning | 5 stratified training folds | Select one of 8 parameter settings per family by mean AP |
| Calibration | 5-fold training OOF scores | Fit a sigmoid without outer-test labels |
| Threshold | Training OOF probabilities | Maximize F1 on the fixed 0.05–0.80 grid |
| Deployment | Refit on all 1,470 records | Selected raw/seven-feature family; no independent final test |

Every employee is held out exactly once in each repeat: 7,350 held-out predictions per specification, not 7,350 independent people. The same outer folds are used across all 14 specifications. All learned preprocessing and role-income references are refitted inside training folds [2].

### What changed from the original project

The 70/20/10 split is replaced as the primary evaluation. Its results are preserved only in a historical archive. The upgraded protocol was fixed before this run, but the dataset and earlier results had already been examined. This is therefore an exploratory extension, not prospective preregistration or an independent replication.

The final family is selected from outer-CV comparisons. Nested CV protects each candidate’s tuning/evaluation separation; selecting the best candidate across those results can still make the winning score optimistic. A new external or temporal test is needed for confirmation.

## Domain guided representations

The original representation is compared with original + eight domain features (“all”). A second version (“no_log”) removes LogMonthlyIncome, retaining seven features to avoid splitting attribution between raw income and its log transform. All three versions are run for every model family; only original and seven-feature candidates are deployment-eligible, as fixed before training.

| Feature | Definition | Block |
| --- | --- | --- |
| OvertimeBalancePressure | I(OverTime = Yes) × (5 − WorkLifeBalance) | Workload |
| OvertimeCommute | I(OverTime = Yes) × DistanceFromHome | Workload |
| PromotionDelayShare | YearsSinceLastPromotion / (YearsAtCompany + 1) | Career |
| RoleTenureShare | YearsInCurrentRole / (YearsAtCompany + 1) | Career |
| ManagerTenureShare | YearsWithCurrManager / (YearsAtCompany + 1) | Career |
| IncomeToRoleMedian | MonthlyIncome / training role median income | Reward |
| LogMonthlyIncome | log(1 + MonthlyIncome) | Reward |
| MeanDissatisfaction | 5 − mean(job, environment, relationship satisfaction) | Sentiment |

IncomeToRoleMedian uses only the training fold’s job-role medians, with its global income median as a fallback for unseen roles. Career denominators add one to handle zero tenure. The sentiment average is a linear combination of existing survey ratings, so it does not create independent information. Distance units and rate-field meanings are not invented.

### Domain rationale and interpretability

Interactions make overtime-plus-balance or overtime-plus-commute relationships explicit to a linear model. Ratios describe career time and pay relative to a reference. These names can aid explanation, but are hypotheses rather than established causes. A high role-tenure share need not mean stagnation, and overtime pressure is not a burnout diagnosis.

Adding correlated features can redistribute credit and increase explanation length. Retaining MonthlyIncome with IncomeToRoleMedian also leaves shared information, because the ratio provides role context. Removing the log-income duplicate reduces one redundant representation; it does not make all inputs independent.

Four logistic ablations remove workload, career, reward or sentiment engineered blocks from the seven-feature version while retaining every original predictor. They are evaluated on the same nested folds and do not enter final selection.

## Models calibration and uncertainty

| Family | Unchanged tuning grid |
| --- | --- |
| Logistic regression | C = 0.05, 0.2, 1, 5; class weight = none or balanced |
| Decision tree | Depth = 3 or 5; minimum leaf = 10 or 25; class weight = none or balanced |
| Random forest | 150 trees; depth = 5 or unrestricted; minimum leaf = 3 or 10; class weight = none or balanced |

Numeric inputs use median imputation and standardization; categorical inputs use most-frequent imputation and one-hot encoding. Ordinal ratings are treated as equally spaced. Pipelines prevent outer-test data from fitting preprocessing statistics. Tuning compares equal eight-setting budgets, not identical fitted hyperparameters.

### Probabilities and threshold

After inner tuning, five-fold out-of-fold scores from the chosen pipeline fit a sigmoid calibrator. The base pipeline is refitted on the whole outer-training fold. Logistic scores are decision-function values; tree and forest scores are clipped probability logits. Tuning and calibration reuse outer-training data, so internal calibration/threshold development is not fully nested. The complete procedure is scored only on its untouched outer-test fold [3].

Thresholds maximize F1 on calibrated training OOF scores over 0.05–0.80 at 0.005 steps, with higher thresholds breaking ties. This can overfit the development scores; outer evaluation measures the resulting procedure. No 294-row validation pool or outer-test threshold tuning is used.

### Metrics and paired intervals

Average precision (AP) is primary because attrition is the minority class; it is not trapezoidal PR-AUC. ROC-AUC assesses ranking. Brier assesses probability error; it is not a pure calibration measure. ECE and reliability curves assess calibration descriptively. Precision, recall, F1 and accuracy use each training-selected threshold.

For 25 matched differences d, corrected SE = sqrt((1/25 + 294/1176) × sample variance(d)). Use Student t with 24 degrees of freedom for approximate 95% intervals and two-sided p-values [4,5]. The correction reflects overlapping training folds. Holm-adjust AP p-values over the three families separately for the eight- and seven-feature comparisons. Ablations, age and other metrics are exploratory.

Report fold means and sample SDs, paired changes, intervals and win counts. Do not interpret the 25 overlapping folds as independent experiments or an interval as a probability that the hypothesis is true.

## Predictive results

| Model | AP ↑ mean ± SD | ROC-AUC ↑ | Brier ↓ |
| --- | --- | --- | --- |
| Logistic original | 0.6172 ± 0.0537 | 0.8254 ± 0.0305 | 0.0962 ± 0.0065 |
| Logistic +8 | 0.6413 ± 0.0463 | 0.8318 ± 0.0302 | 0.0936 ± 0.0065 |
| Logistic +7 | 0.6282 ± 0.0501 | 0.8287 ± 0.0311 | 0.0948 ± 0.0065 |
| Tree original | 0.4007 ± 0.0654 | 0.7257 ± 0.0345 | 0.1258 ± 0.0050 |
| Tree +8 | 0.3875 ± 0.0575 | 0.7220 ± 0.0404 | 0.1266 ± 0.0027 |
| Tree +7 | 0.3855 ± 0.0600 | 0.7253 ± 0.0450 | 0.1264 ± 0.0036 |
| Forest original | 0.5394 ± 0.0682 | 0.7973 ± 0.0379 | 0.1051 ± 0.0078 |
| Forest +8 | 0.5397 ± 0.0664 | 0.8011 ± 0.0385 | 0.1049 ± 0.0073 |
| Forest +7 | 0.5461 ± 0.0644 | 0.8005 ± 0.0356 | 0.1042 ± 0.0070 |

![feature_comparison.png](../results/feature_comparison.png)

Figure 1. Matched repeated nested-CV average precision. “+8” is the original engineered design; “+7” removes LogMonthlyIncome.

Selected among raw/+7 candidates: logistic_no_log. Mean outer precision 0.5724, recall 0.5594, F1 0.5574, and accuracy 0.8580. These means use fold-specific training-selected thresholds; the final full-data threshold is 0.290.

The positive prevalence is 16.12%, illustrating why accuracy alone is insufficient. A training-prior baseline is included separately in results/prior_baseline.csv. The main tables and app are generated from the same saved outer predictions.

## Paired changes and ablations

Each value below is engineered minus original AP on the same 25 outer folds. A positive difference favors engineering. An interval crossing zero indicates unresolved direction under the corrected approximation; a win count alone is not a significance test.

| Candidate | AP change [95% interval] | Wins /25 | Holm p |
| --- | --- | --- | --- |
| Logistic +8 | 0.0241 [-0.0014, 0.0496] | 23 | 0.1884 |
| Tree +8 | -0.0132 [-0.0602, 0.0339] | 8 | 1.0000 |
| Forest +8 | 0.0002 [-0.0266, 0.0270] | 11 | 1.0000 |
| Logistic +7 | 0.0111 [-0.0131, 0.0353] | 15 | 1.0000 |
| Tree +7 | -0.0152 [-0.0636, 0.0331] | 8 | 1.0000 |
| Forest +7 | 0.0067 [-0.0262, 0.0395] | 14 | 1.0000 |

Seven-feature logistic versus original: The corrected interval includes zero, so the apparent performance difference is uncertain. Holm-adjusted AP p-value: 1.0000.

The original eight-feature logistic arm has mean AP 0.6413, a change of +0.0241 versus original predictors (corrected 95% interval [-0.0014, +0.0496]; 23/25 fold wins). Forest AP changes are +0.0002 with eight features and +0.0067 with seven; their corrected intervals include zero. Both engineered decision-tree arms have lower mean AP than the original arm.

### Remove one engineered block from seven features

| Removed block | Mean AP | AP change vs +7 [95% interval] |
| --- | --- | --- |
| Workload | 0.6329 | 0.0047 [-0.0118, 0.0212] |
| Career | 0.6214 | -0.0069 [-0.0286, 0.0149] |
| Reward | 0.6225 | -0.0057 [-0.0204, 0.0090] |
| Sentiment | 0.6280 | -0.0003 [-0.0024, 0.0019] |

Each ablation is retuned within each outer-training fold. Original predictors remain. A negative change suggests that the removed block helped the tuned procedure, but these exploratory intervals are unadjusted and can overlap zero.

### Age sensitivity and fairness scope

Adding Age to seven-feature logistic gives mean AP 0.6311; change +0.0029, corrected interval [-0.0115, +0.0172]. This is an information sensitivity check, not a fairness test. Age remains excluded from the deployed main model, along with Gender and MaritalStatus.

The full paired table also reports ROC-AUC and Brier changes. Its Brier direction is reversed: lower is better. Differences between engineered variants must not be cherry-picked to imply a universal benefit.

## Interpretability results

All six logistic and forest representations cover 1,470 employees, each held out once per repeat. Fifty stratified bootstrap refits per outer fold, with tuned parameters fixed, yield 7,500 refits.

| Representation | Mean K80 ↓ [95% interval] | Top-3 Jaccard ↑ [95% interval] |
| --- | --- | --- |
| Logistic original | 12.09 [11.99, 12.19] | 0.600 [0.596, 0.605] |
| Logistic +8 | 13.10 [12.96, 13.21] | 0.635 [0.628, 0.644] |
| Logistic +7 | 13.51 [13.35, 13.65] | 0.567 [0.558, 0.577] |
| Forest original | 11.73 [11.30, 12.17] | 0.579 [0.574, 0.583] |
| Forest +8 | 16.23 [16.04, 16.42] | 0.471 [0.464, 0.479] |
| Forest +7 | 15.35 [15.06, 15.64] | 0.493 [0.489, 0.499] |

K80 counts attributes covering 80% of absolute contribution mass. Jaccard measures top-three set overlap after bootstrap refitting. One-hot levels are grouped by source attribute. These proxies measure compactness and stability, not human comprehension.

Logistic +7: stability change -0.0338; K80 change +1.43 attributes (lower is better).

For the eight-feature logistic arm, stability changes by +0.0341 and K80 by +1.02. Interpretability dimensions must therefore be assessed separately.

### Intervals and random-forest coverage

Intervals use 10,000 bootstrap draws of five repeat means, matched for paired changes. They describe conditional split variability, not population uncertainty: repeats share data and only five means are available. Adding attributes can mechanically increase K80.

Logistic contributions use calibrated log-odds. Forest TreeSHAP uses uncalibrated class-1 probability with a tree-path-dependent background [6]. Their magnitudes have different units. The app separately explains calibrated probabilities through six groups.

### Ranking agreement and fidelity

| Model | Spearman vs permutation ranks [95% interval] |
| --- | --- |
| Forest +8 | 0.370 [0.320, 0.427] |
| Forest +7 | 0.361 [0.328, 0.380] |
| Forest original | 0.441 [0.397, 0.481] |
| Logistic +8 | 0.820 [0.801, 0.838] |
| Logistic +7 | 0.784 [0.754, 0.813] |
| Logistic original | 0.773 [0.753, 0.798] |

Five-shuffle permutation AP drops cross-check representation reliance [7]. Independent derived-column permutations can create inconsistent combinations. Spearman agreement does not establish causality or human clarity; additivity is checked separately. No human study was performed.

## Probability calibration

For the selected logistic_no_log procedure, ten-bin ECE averages 0.0287 across five repeats (SD 0.0019). Mean outer Brier is 0.0948 (SD 0.0065). Lower is better for both metrics.

![calibration_curve.png](../results/calibration_curve.png)

Figure 2. Reliability curves from held-out predictions. Pale lines show individual repeats; the stronger line pools predictions descriptively. Perfect calibration follows the diagonal.

| Repeat | ECE |
| --- | --- |
| 1 | 0.0278 |
| 2 | 0.0277 |
| 3 | 0.0271 |
| 4 | 0.0319 |
| 5 | 0.0292 |

ECE is the weighted absolute difference between mean prediction and observed positive rate within ten equal-width probability bins. Empty bins are omitted. Values depend on binning and finite sample size, particularly in high-probability bins with few employees. Brier also reflects discrimination and uncertainty, so neither metric alone proves calibrated individual risk.

The plot pools 7,350 held-out predictions from 1,470 employees. Its bin counts are repeated observations, not independent employees. These curves evaluate the selected training procedure; they are not an external calibration guarantee for the final model refitted on all records.

## Individual prediction and group explanation

The same fictional employee, ID 478, is evaluated by original and seven-feature logistic models from outer fold 5 of the first repeat. This employee is excluded from both models’ training and reference data. It was already used as a high-risk illustration in the original project, so it is not a representative or randomly selected case.

| Model | Attrition probability | Threshold | Class |
| --- | --- | --- | --- |
| Original | 95.13% | 0.245 | Attrition |
| Original +7 | 94.06% | 0.245 | Attrition |

### Six concept groups in probability units

Enumerate all 64 combinations of six raw-input groups against 32 fixed training-background records, recomputing engineered features for every hybrid. Exact Shapley weights allocate the prediction difference to workload, satisfaction, career, pay, education and role groups. Each contribution is in probability percentage points.

![example_factors.png](../results/example_factors.png)

Figure 3. +7 model: reference 18.14%, prediction 94.06%. Rounded values are shown; the unrounded contributions reconstruct the probability exactly.

These group explanations describe model associations relative to a reference, not confirmed causes of leaving. Combining correlated groups from different employees can create unrealistic profiles. Changing a displayed factor does not establish a real-world treatment effect.

The app uses final models refitted on all development records. Its probabilities for this employee can differ from the held-out illustration, and in-sample demo profiles are not evaluation evidence.

## Same employee and named domain attributes

The detailed logistic explanation uses a training-mean baseline. For transformed attribute j, contribution = a × beta_j × (z_j − mean_training_j). Baseline plus all contributions, followed by the sigmoid, exactly reconstructs the calibrated probability. One-hot categories are combined into the original attribute.

| Model | Top attribute | Log-odds |
| --- | --- | --- |
| Original | Overtime | +1.183 |
| Original | Environment satisfaction | +0.734 |
| Original | Business travel | +0.696 |
| Original +7 | Job role | +1.487 |
| Original +7 | Overtime | +1.388 |
| Original +7 | Monthly income | -0.888 |

### Engineered factors in the seven feature explanation

| Named domain factor | Value | Log-odds |
| --- | --- | --- |
| Overtime balance pressure | 2.000 | -0.331 |
| Mean dissatisfaction | 3.000 | +0.310 |
| Income relative to role median | 0.838 | +0.293 |
| Overtime commute | 1.000 | -0.030 |
| Role tenure share | 0.500 | -0.024 |
| Manager tenure share | 0.500 | -0.004 |
| Promotion delay share | 0.250 | -0.002 |

Overtime balance pressure: I(OverTime = Yes) × (5 − WorkLifeBalance). For this employee it lowers the calibrated model score by 0.331 log-odds relative to the transformed training mean.

Mean dissatisfaction: 5 − mean(job, environment, relationship satisfaction). For this employee it raises the calibrated model score by 0.310 log-odds relative to the transformed training mean.

A positive sign raises the score and a negative sign lowers it. Log-odds are not percentage points and cannot be added directly to the probability. The feature baseline differs from the six-group background-probability reference; each decomposition is internally additive. The app displays every domain definition next to its contribution.

The seven-feature version contains MonthlyIncome once as its raw scale, plus the role-relative ratio. LogMonthlyIncome remains only in the original eight-feature comparator. Correlation can still distribute contribution among pay, role and tenure inputs.

## Implementation verification and demonstration

| Component | Purpose |
| --- | --- |
| train.py | 25 outer folds, inner tuning, ablations, CV thresholds, final refit |
| attrition.py / explanations.py | Fold-local features, probabilities, validation, additive explanations |
| interpretability.py | All-held-out K80, 50 bootstrap refits per fold, TreeSHAP and rank checks |
| app.py / predict.py | Interactive and CLI prediction, side-by-side explanations and export |
| notebooks / scripts | Executed walkthrough; shared data-driven charts and report |
| verify.py / tests | Fold coverage, metrics, medians, calibration, explanations and UI |

### Run the supplied system

Extract the entire ZIP, create a Python 3.12 environment, then run: pip install -r requirements.txt; python verify.py; python -m streamlit run app.py. The trained bundle is included, so full retraining is not needed for a classroom demonstration. Complete Windows commands are in docs/RUN_WINDOWS.md.

For full reproduction, first install requirements-report.txt, then run python reproduce.py --destination ../Attrition_Reproduced --jobs 6. This recreates 350 outer model fits and 7,500 bootstrap refits in a new directory. Runtime depends on the machine. The supplied notebook explores and verifies saved results without repeating this expensive stage.

### Demonstration sequence

Select a fictional employee, estimate its probability, and explain the thresholded class. Read one increasing and one decreasing factor with the correct units. Compare original versus engineered explanations for that same profile. Show nested-CV AP intervals, block ablations, calibration and interpretation diagnostics. End with the measured research answer and its limits.

### Verification evidence

Checks recompute saved fold metrics from all outer predictions, verify matched fold coverage and training-only income medians, check final model selection, reproduce calibration bins, inspect bootstrap counts and interval calculations, and test explanation additivity. UI tests cover valid prediction, invalid input rejection, recovery and changing profiles. The notebook is executed. Verification output is supplied in results; runtime checks were performed on Linux. verify.py was also run on Windows 11 in the pinned Python 3.13 environment (see docs/WINDOWS_VERIFICATION.md).

### Optional human evaluation

The supplied rubric specifies a blinded, counterbalanced 1–5 clarity/usefulness exercise with 5–10 classmates, five fixed fictional profiles, and comprehension questions. The response CSV is empty. No responses were collected or fabricated; numerical proxies cannot substitute for that study.

## Gap closure: locked holdout, subgroup audit, human-study readiness

This section was added after the first review. It reports only what was run. Items that need data or people that the project does not have are marked as not performed.

### Locked holdout test (independent of selection)

A fixed stratified split (seed 20260101) set aside 294 employees before any model comparison. Selection used only the remaining 1,176 development rows, with the same nested-CV, calibration, threshold and winner rules. The selected model was logistic_no_log. It was refitted on all development rows and scored once on the holdout. This removes selection optimism from the holdout number. It does not make the test external: it is still the same fictional dataset.

| Model | Holdout AP | ROC-AUC | Brier | F1 (dev threshold) | Selected |
| --- | --- | --- | --- | --- | --- |
| logistic_raw | 0.6106 | 0.8568 | 0.0930 | 0.5814 |  |
| logistic_no_log | 0.6300 | 0.8630 | 0.0927 | 0.5918 | yes |
| tree_raw | 0.3323 | 0.6900 | 0.1255 | 0.3922 |  |
| tree_no_log | 0.3304 | 0.7222 | 0.1266 | 0.4444 |  |
| forest_raw | 0.4994 | 0.8126 | 0.1075 | 0.4954 |  |
| forest_no_log | 0.4746 | 0.7692 | 0.1114 | 0.5000 |  |

Holdout AP difference, selected minus logistic_raw: +0.0194, bootstrap 95% percentile interval [-0.0667, +0.0797] over 294 employees. The holdout is 20% of the data, so this interval is wide and should be read descriptively.

### Subgroup audit: Gender, marital status, age band

The saved held-out predictions for every employee were grouped by attributes that the model excluded. Gaps are the largest minus smallest group value. Intervals resample employees, keeping each employee's five held-out predictions together.

| Attribute | Flagged-rate gap [95%] | True-positive gap [95%] | False-positive gap [95%] |
| --- | --- | --- | --- |
| Gender | 0.018 0.001 to 0.056 | 0.068 0.003 to 0.187 | 0.021 0.001 to 0.049 |
| MaritalStatus | 0.128 0.087 to 0.178 | 0.231 0.125 to 0.367 | 0.042 0.012 to 0.078 |
| AgeBand | 0.163 0.115 to 0.213 | 0.275 0.137 to 0.408 | 0.049 0.015 to 0.095 |

Groups are descriptive. Some subgroups are small, so intervals are wide. The audit does not establish fairness: excluded attributes can still be proxied by other inputs.

### Human clarity study: materials ready, no ratings

Status: not performed. The packet (ten participant cards, counterbalanced A/B assignment, blinded key and analysis script) is built from the rubric. No ratings were collected or created. Interpretability on this page is measured by K80 and stability proxies only, until the study is run.

### Temporal validation

Not performed. The dataset has no observation or departure dates. scripts/temporal_validation.py is ready for a dated extract with a stated horizon, but no such extract is in this project.

## Conclusion limitations and references

The study does not demonstrate simultaneous improvement in prediction and interpretability for the seven-feature logistic model; the measured trade-offs must be reported separately. The seven-feature logistic model changes mean average precision from 0.6172 to 0.6282 (paired difference +0.0111; corrected 95% interval [-0.0131, +0.0353]). Top-three stability changes by -0.0338, while K80 changes by +1.43 attributes (lower K80 is better). No human clarity study has been performed.

### What this project establishes

The system meets the original objective by producing an attrition-label probability, a class, and an interpretable individual explanation, while testing domain engineering in controlled model comparisons. Findings are model-specific and measure-specific. A mixed result is a valid research conclusion, not a reason to replace measured results with the hoped-for answer.

### Limits and next steps

The data are fictional and cross-sectional; feature timing relative to attrition is unknown. There is no prospective turnover horizon or external test; the locked holdout is an internal split of the same fictional data. No human comprehension study has been run. The subgroup audit is descriptive and reports gaps that were not removed. The dataset was already examined before this upgrade. Outer folds overlap; corrected t inference is approximate and interpretation intervals use only five repeat means. Tuning and calibration share development data; choosing a winner across outer comparisons adds selection optimism.

Correlated or redundant attributes can share explanation credit, and intervention-style hybrids may be implausible. Stability conditions on selected parameters, not all model-selection uncertainty. TreeSHAP diagnostics explain the base forest, not its calibrated probability. A real forecasting study needs dated longitudinal data, temporal validation, a specified horizon, external testing, calibration monitoring and carefully designed human evaluation. This prototype is for coursework.

### References

[1] IBM HR Analytics Employee Attrition and Performance. Kaggle. https://www.kaggle.com/datasets/pavansubhasht/ibm-hr-analytics-attrition-dataset

[2] scikit-learn. Nested versus non-nested cross-validation. https://scikit-learn.org/stable/auto_examples/model_selection/plot_nested_cross_validation_iris.html

[3] scikit-learn. Probability calibration. https://scikit-learn.org/stable/modules/calibration.html

[4] scikit-learn. Statistical comparison of models using grid search. https://scikit-learn.org/stable/auto_examples/model_selection/plot_grid_search_stats.html

[5] Nadeau, C. and Bengio, Y. Inference for the Generalization Error. NeurIPS, 1999. https://papers.nips.cc/paper/1999/file/7d12b66d3df6af8d429c1a357d8b9e1a-Paper.pdf

[6] SHAP. TreeExplainer documentation. https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html

[7] scikit-learn. Permutation feature importance. https://scikit-learn.org/stable/modules/permutation_importance.html
