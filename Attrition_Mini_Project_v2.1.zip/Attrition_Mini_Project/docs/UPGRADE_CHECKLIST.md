# Upgrade plan implementation map

| Requested change | Implementation / evidence |
|---|---|
| Repeated nested CV, all employees | `train.py`, `results/split_manifest.json`, 25 matched outer folds |
| Keep original grids, three families | Eight parameter settings per family; raw/all/no_log arms |
| Mean/SD, paired intervals and wins | `nested_cv_summary.csv`, `paired_comparisons.csv` |
| Correct dependent CV inference | Approximate Nadeau–Bengio corrected t intervals; Holm AP adjustment |
| Four feature-block ablations | Logistic without_* arms relative to no_log on identical nested folds |
| Select final model empirically | `selection.json`, rebuilt `models/bundle.joblib` |
| Remove duplicate income attribution | Seven-feature candidate omits LogMonthlyIncome; eight-feature comparator retained |
| Named domain factors and formulas | `explanations.py`, app comparison panel and report worked example |
| All-held-out interpretation metrics | `interpretability.py`, employee-level outputs and repeat intervals |
| More bootstrap refits | 50 stratified refits per outer fold and representation |
| Include random forests | TreeSHAP base-probability contributions and permutation-ranking cross-check |
| Side-by-side employee example | `example_comparison.json`, held-out example models, app comparison |
| Calibration and ECE | Reliability curves, ten-bin repeat ECE, app calibration tab |
| Age sensitivity | Separate no_log_age experiment; main model excludes Age |
| Human clarity/usefulness evaluation | Rubric and empty template provided; **study not performed** |
| New report, notebook and app | Shared measured CSV/JSON sources; no old primary-result tables |
| Reproducibility and tests | Fold/metric/additivity verification, UI checks, executed notebook, checksums |

## Decisions and limits

The old single 70/20/10 experiment is retained only as a historical ZIP in `archive/`. It is fully replaced as the main evaluation. The original eight-feature specification is still tested for all three families; a separately declared seven-feature production candidate removes duplicate log-income attribution. Deployment eligibility is raw/no_log. Ablations use no_log so they diagnose the production design.

The upgrade does not invent participant data. Human understanding remains untested. Age sensitivity is not a fairness audit. The source is fictional and has no dated turnover horizon. Corrected predictive inference is approximate; interpretation intervals describe five-repeat conditional split variation. Candidate selection uses the outer comparisons, so the selected winner still needs an external confirmation test.
