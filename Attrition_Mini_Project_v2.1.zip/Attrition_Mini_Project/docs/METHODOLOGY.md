# Upgraded methodology

The professor's objective is to estimate an individual attrition probability, explain its major associated factors, and investigate whether domain-informed features improve prediction and interpretability together. This is an exploratory extension of an already examined dataset, not a new preregistered study. `protocol.json` was fixed before the upgraded run; `results/protocol_lock.json` records the fitting-code fingerprint. Old 70/20/10 outputs are preserved only in `archive/legacy_70_20_10_results.zip`.

## Dataset and features

The fictional IBM HR dataset has 1,470 employees, 237 positive labels, 35 source columns, and no documented prediction horizon. The target is Attrition=Yes. EmployeeNumber and three constant fields are removed. Age, Gender and MaritalStatus are excluded from the principal models; an explicit age-addition sensitivity analysis is separate. The original representation has 27 predictors.

`all` retains those 27 predictors and adds eight features. `no_log` retains the 27 plus seven, removing LogMonthlyIncome to avoid the same income scale receiving both raw-income and log-income attribution. The original eight-feature experiment remains available for the requested comparison. Deployment eligibility is fixed to raw/no_log before observing upgraded results; all is a research comparator.

| Block | Feature | Formula |
|---|---|---|
| Workload | OvertimeBalancePressure | I(OverTime=Yes) × (5−WorkLifeBalance) |
| Workload | OvertimeCommute | I(OverTime=Yes) × DistanceFromHome |
| Career | PromotionDelayShare | YearsSinceLastPromotion/(YearsAtCompany+1) |
| Career | RoleTenureShare | YearsInCurrentRole/(YearsAtCompany+1) |
| Career | ManagerTenureShare | YearsWithCurrManager/(YearsAtCompany+1) |
| Reward | IncomeToRoleMedian | MonthlyIncome/training-fold JobRole income median |
| Reward | LogMonthlyIncome | log(1+MonthlyIncome), eight-feature comparator only |
| Sentiment | MeanDissatisfaction | 5−mean(Job, Environment, Relationship Satisfaction) |

Unseen roles use the training global income median. The denominator is floored at 1. Every imputer, scaler, encoder and role median is learned inside its own training fold. Numeric survey codes are treated as equally spaced; this is a simplifying assumption. Features are hypotheses, not validated psychological constructs or causes.

## Repeated nested validation

Use all 1,470 records with RepeatedStratifiedKFold(5 folds, 5 repeats, seed 42). Each of 25 outer splits has 1,176 training and 294 test rows. Every employee is held out exactly once per repeat. The same folds are used for all 14 specifications:

- Logistic regression, decision tree and random forest, each with raw/all/no_log (9).
- Four logistic ablations, removing one engineered block from no_log while retaining all originals (4).
- Logistic no_log with Age added as an exploratory sensitivity analysis (1).

Five-fold shuffled stratified inner CV selects hyperparameters by mean average precision (AP). Seed = 1000+10×outer-fold index. Preserve the original eight-point grids: logistic C in {0.05,0.2,1,5} and class_weight in {None,balanced}; tree depth {3,5}, leaf {10,25}, class_weight {None,balanced}; forest 150 trees, depth {5,None}, leaf {3,10}, class_weight {None,balanced}. All model seeds are 42. AP is not trapezoidal PR-AUC.

After tuning, generate five-fold OOF scores from the selected pipeline on outer-training rows, with seed inner_seed+1. Fit a logistic sigmoid to these scores and training labels. Full-training base scores are decision_function for logistic; clipped probability logits for trees/forests. Hyperparameter selection and calibration reuse the outer-training sample, so these internal scores are not fully nested or unbiased estimates of tuning/calibration performance. The complete procedure is evaluated on untouched outer-test rows. No outer-test values or labels fit a preprocessing statistic, calibrator or threshold.

Choose the threshold by maximizing F1 on calibrated training OOF scores over 0.05–0.80 in 0.005 steps; higher threshold wins ties. The sigmoid is fitted on those same training OOF scores, so threshold development can overfit that training sample; outer test evaluation measures the resulting procedure. There is no separate 294-row validation pool in the upgraded experiment.

## Selection and metrics

Report fold means and sample SDs for AP, ROC-AUC, Brier, ECE, precision, recall, F1 and accuracy. Folds are dependent. Select the final family/representation by mean outer AP among the six raw/no_log candidates; lower mean Brier then model key breaks exact ties. Four ablations and the age sensitivity are diagnostic only. Refit the selected model on all 1,470 development rows using five-fold tuning and OOF sigmoid/threshold selection (seed 5000/5001). Also save raw/all/no_log logistic models for demonstrations.

Nested outer scoring evaluates each fixed candidate training procedure. Selecting the winner across these outer results adds selection optimism; the winning score is not an untouched final-test score. There is no new independent test set in this upgrade.

The probability CSV retains full precision. When recomputing ranking metrics, load it with `pd.read_csv(..., float_precision='round_trip')`: the default parser can merge adjacent floating-point tree scores and change AP/AUC tie handling. The verification script checks every saved metric against the round-tripped probabilities.

## Paired uncertainty

For a metric, compute 25 matched candidate-minus-reference differences d. The Nadeau–Bengio-style corrected standard error is sqrt((1/25 + 294/1176) × sample_variance(d)). Use Student t with 24 degrees of freedom for a two-sided test and 95% interval. This is approximate dependent-CV inference, not an exact guarantee. Positive AP/ROC differences are favorable; negative Brier differences are favorable. Report wins and ties. For the three primary AP family comparisons, apply Holm correction separately within all and no_log. Other metrics, four ablations and age are exploratory, unadjusted diagnostics; do not cherry-pick significant values.

## Calibration

Use ten equal-width probability bins. ECE = sum(n_bin/N × |mean_probability−observed_rate|); omit empty bins. Compute ECE within each repeat's 1,470 held-out predictions, then report mean and SD across repeats. Plot those five reliability curves plus the descriptive pooled curve. The pooled 7,350 observations are repeated predictions for 1,470 employees; no independence is claimed. Report Brier alongside ECE. ECE is bin-dependent and finite-sample biased. Calibration is evaluated, not guaranteed.

## Explanations

For a sigmoid-calibrated logistic model, logit(p)=a×(c+beta·z)+b. The exact attribute contribution is a×beta_j×(z_j−mu_j), where mu is the mean transformed training vector. Baseline=a×(c+beta·mu)+b. Sum contributions into source attributes for one-hot variables. These are calibrated log-odds, not percentage points. Engineered attributes receive an explicit tag and formula.

The model-agnostic explanation groups 27 raw inputs into six work concepts. Enumerate all 64 coalitions against 32 fixed training records, recomputing domain features through the fitted pipeline for each hybrid. Exact Shapley weights distribute the difference from mean background probability to employee probability. Values are probability percentage points; their reference differs from the linear explanation. Both decompositions are checked for additivity. Correlated-group hybrids can be unrealistic; neither explanation is causal.

The same-employee comparison reuses prior illustrative employee 478, using models from the first repeat where that employee was held out. It was previously chosen for high predicted risk, so it is not representative. App predictions use the final all-development-data refits; those are deliberately separate from the held-out example.

## Interpretability diagnostics

For logistic and forest in raw/all/no_log, evaluate all 7,350 outer-held-out observations (1,470 unique employees per model). K80 is the smallest source-attribute count accounting for 80% of absolute contribution mass; report its mean. One-hot levels are summed before ranking. Top-three stability is mean Jaccard overlap with the original fitted explanation across 50 stratified bootstrap refits per outer fold. Six models ×25 folds ×50 =7,500 refits. Hyperparameters are fixed at the outer-selected values; bootstraps do not retune. Positive scalar sigmoid calibration cannot change K80 or absolute top-three ranks in a linear model.

Forest attribution uses exact TreeSHAP with tree_path_dependent background and base class-1 probability output. This is BEFORE sigmoid calibration, clearly distinct from the app's calibrated six-group explanation. Refitting changes the tree background implicitly. Linear bootstrap explanations use the same outer-training reference records transformed by the refitted preprocessing. Cross-family magnitudes are not comparable.

Average row-level metrics within each repeat, then bootstrap the five repeat means 10,000 times. Report 95% percentile intervals for each arm and paired differences using matched repeat draws. These are descriptive intervals for split variability conditional on one dataset and only five repeats, not population confidence intervals or independent replications. K80 alone may increase mechanically as more attributes are introduced.

Compare held-out mean absolute attribution ranks with held-out AP-drop permutation importance via Spearman correlation, five shuffles per source attribute. All one-hot levels of a categorical input are shuffled together. Here permutations act on the transformed representation; independently changing an engineered column can break deterministic relationships. This is a representation-reliance diagnostic, not a realistic employee intervention. Ranking agreement is not mathematical fidelity; additivity is checked separately, and neither establishes human clarity.

## Sources

- Dataset: https://www.kaggle.com/datasets/pavansubhasht/ibm-hr-analytics-attrition-dataset
- Nested CV: https://scikit-learn.org/stable/auto_examples/model_selection/plot_nested_cross_validation_iris.html
- Corrected comparisons: https://scikit-learn.org/stable/auto_examples/model_selection/plot_grid_search_stats.html
- Nadeau and Bengio, Inference for the Generalization Error: https://papers.nips.cc/paper/1999/file/7d12b66d3df6af8d429c1a357d8b9e1a-Paper.pdf
- Calibration: https://scikit-learn.org/stable/modules/calibration.html
- Permutation importance: https://scikit-learn.org/stable/modules/permutation_importance.html
- TreeSHAP API: https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html

No human clarity study has been performed. A separate rubric and empty response template are provided. Age exclusion does not establish fairness: work attributes can proxy protected characteristics. Real deployment would require dated longitudinal data, a specified turnover horizon, external validation, subgroup/error auditing and human governance.

## Optional computational acceleration

The reference computation uses SHAP 0.50.0. The supplied run may also use the numerically matched exact FastTreeSHAP v1 implementation (0.1.6), with one thread per worker. `scripts/verify_fast_backend.py` compares every contribution, K80 and top-three set against the reference on 882 held-out observations across three forest representations; its actual output is in `results/explanation_backend.json`. This changes computation speed, not fitted models, folds, attribution definition or bootstrap sample counts. The standard reproduction path uses SHAP and does not require FastTreeSHAP. The optional Unix accelerator needs a C++ compiler and the legacy NumPy scalar-conversion compatibility wrapper in `fast_tree_backend.py`.

Source: LinkedIn FastTreeSHAP implementation, https://github.com/linkedin/FastTreeSHAP .
