# Viva and demonstration guide

## A two-minute demonstration

1. State the objective: estimate attrition probability and explain the major factors, then test domain-informed features against original predictors.
2. Launch the app and submit a fictional employee profile. Explain the difference between probability and the thresholded class.
3. Read a signed group contribution in percentage points. Read one tagged domain feature, its formula and calibrated log-odds contribution.
4. Show the same employee under original and seven-feature logistic models. Explain that this is a model comparison, not an intervention effect.
5. Show mean AP, corrected paired intervals and the calibration plot. Explain why 25 overlapping folds are not independent.
6. Show compactness and stability intervals. Read the measured answer in the app; do not claim that all models or all interpretation measures improved.

## Likely questions

**Why repeated nested CV?** Inner CV chooses hyperparameters; the outer fold evaluates the complete training procedure on held-out rows. Repeats reduce dependence on one favorable or unfavorable split. They do not create new independent datasets.

**What is the target?** The dataset's binary Attrition label. There is no future time window, so this is not a validated six-month or annual turnover forecast.

**Why average precision?** Positive labels are only 237/1,470. AP emphasizes ranking of the minority positive class; always predicting “stay” can have high accuracy and zero attrition recall.

**Where can leakage occur?** Scaling, imputation, encoding, salary medians, tuning, calibration and threshold selection. All are learned using outer-training rows only. The code audits salary medians and fold membership.

**Why eight and seven features?** Eight preserves the original research design. Seven removes LogMonthlyIncome to avoid attributing the same income scale twice alongside MonthlyIncome. The salary-to-role ratio remains because it expresses a contextual comparison.

**Why exclude Age but test it separately?** The principal model focuses on work-related attributes. The age-addition experiment measures sensitivity to an excluded attribute. It does not test fairness, and excluding protected attributes does not remove all proxies.

**How is the threshold chosen?** By maximum training-CV F1 on a fixed grid, not outer-test outcomes. A real organization would need justified error costs and governance rather than accepting this classroom rule.

**What does calibration do?** A sigmoid maps cross-validated training scores to probabilities. Reliability curves and ECE evaluate agreement with observed frequencies; calibration is attempted, not guaranteed.

**How do explanations reconstruct probability?** For logistic features, sum calibrated log-odds contributions and the baseline, then apply sigmoid. For six-group Shapley, add probability-point contributions to mean background probability. Their units and references differ.

**Does TreeSHAP explain the calibrated forest?** The research diagnostics explain its uncalibrated base probability. The model-agnostic six-group explanation can explain calibrated predictions separately. Do not mix the two.

**Does more stable mean more understandable?** No. Stability and K80 are proxies. The optional clarity/usefulness rubric is supplied, but no human study was performed.

**What is the final conclusion?** Read `docs/RESULTS_AND_CONCLUSION.md` for the actual generated result. Report AP changes and intervals together with both interpretation measures. Mixed results are valid and should not be edited into the hoped-for hypothesis.

**What remains limited?** Fictional data, unknown timing, no forecast horizon or external test, selection optimism across candidate families, dependent folds, five-repeat proxy intervals, correlated inputs, and no human comprehension or subgroup fairness study.
